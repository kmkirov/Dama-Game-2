package com.game.constants;

public class GameConstants 
{
	public static final String FIRST_PLAYER_NAME = "first player";
	public static final String SECOND_PLAYER_NAME = "second player";
	public static final int WINS_TYPE = 1; 
	public static final int LOOSES_TYPE = 2; 
	public static final int ID_TYPE = 3; 
}
